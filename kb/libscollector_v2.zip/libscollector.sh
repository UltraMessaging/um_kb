#!/bin/bash

# libscollector.sh - collects core file Executable and pertinent libraries
# Author - Harish Kumar Panda 
# contributors -
# Thiru (Mac OS X)
# Ajay (HP UX)
# last modification date is $BUILDDATE
# 
# This version of the tool supports AIX, HP UX, Linux, Solaris and Mac OS X platform
# TODO: add the dbx init, gdb init file and a opencore script

TOOLVERSION=1.1
BUILDDATE=2022-01-31

printbanner(){
echo
echo "libscollector - script to package core and its dependent libraries for offline analysis"
echo "Version - $TOOLVERSION ($BUILDDATE)"
echo
}

printusage(){
	printbanner
    echo
    echo "Usage: ./libscollector.sh <path to executable> <path to core>"
    echo
    echo "Result: The output file name will vary based on the platform as below"
    echo "Linux            coreName_libs_all.tar.gz"
    echo "HPUX & Solaris   coreName_libs_all.tar.Z"
    echo "AIX              snapcore_xxxxx.pax.Z"
    echo
    echo "Example: if core name is core.12345 then the output will be core.12345_libs_all.tar.gz or core.12345_libs_all.tar.Z"
    echo "More details are in Infa KB - https://knowledge.informatica.com/s/article/144522"
	echo 
    exit
}

checkfileexists(){
    echo checking for $EXECFILE
    if file $EXECFILE | grep "executable" > /dev/null
    then
		echo executable: $EXECFILE exists and is a valid executable
    elif [[ -x $EXECFILE ]]
	then
		echo executable: $EXECFILE exists and is a valid executable
	else
		echo executable: $EXECFILE does not exists or not a valid executable
        exit
    fi
	
	echo Checking for core file: $COREFILE
	if file $COREFILE | grep "core file" > /dev/null
	then
		echo core file: $COREFILE exists
		echo
	else
		echo core file: $COREFILE does not exist or not a valid core
		exit
	fi
}

collectLibsSunOS(){
#use pmap utility to get information of executable and loaded libraries in core

    pmap $COREFILE | /usr/bin/head -2 | /usr/bin/tail -1 | /usr/bin/awk '{ print $4 }' > /tmp/temp_liball.log
    pmap $COREFILE | grep lib | awk '{print $NF}' | sort -u >> /tmp/temp_liball.log

    echo collecting corefile ...
    tar -cvhf $OUTPUTFILE $COREFILE 2> /dev/null

    echo collecting libraries and executable ...

    for i in `cat /tmp/temp_liball.log`
    do
        tar -uvhf $OUTPUTFILE $i 2>/dev/null
    done
    compress $OUTPUTFILE

    echo
    echo "Collected all the libs, executable and core."
    echo "upload $OUTPUTFILE.Z"

    # Delete temporary files
    rm /tmp/temp_liball.log
    exit 0
}

#we need gdb to get the information about librarys loaded in core
collectLibsLinux(){
#Preparng the gdb command file
        echo "file $EXECFILE" > /tmp/temp_gdb_command_file
        echo "core $COREFILE" >> /tmp/temp_gdb_command_file
        echo "info sharedlibrary" >> /tmp/temp_gdb_command_file
        echo "quit" >> /tmp/temp_gdb_command_file
        gdb < /tmp/temp_gdb_command_file > /tmp/temp_gdb.log

#create a tar file and add executable plus core
        echo collecting corefile and executable ...
        #rm -f libs_all.tar.gz
        tar -cvf $OUTPUTFILE $EXECFILE $COREFILE 2> /dev/null

#Collect the libraries loaded and update the tar
        echo collecting libraries...
        grep -i yes /tmp/temp_gdb.log | grep -i 0x | awk '{print $NF}' > /tmp/temp_liball.log
        for i in `cat /tmp/temp_liball.log`
        do
	    tar -uvhf $OUTPUTFILE $i 2>/dev/null	#h option will follow the links as well
        done

        gzip $OUTPUTFILE
        echo
        echo "Collected all the libs, executable and core."
        echo "upload $OUTPUTFILE.gz"

        # Delete temporary files
        rm -rf /tmp/temp_gdb_command_file /tmp/temp_gdb.log /tmp/temp_liball.log libs
        exit 0
}

#we need gdb to get the information about librarys loaded in core
collectLibsHPUX(){
#Preparng the gdb command file
        echo "file $EXECFILE" > /tmp/temp_gdb_command_file
        echo "core $COREFILE" >> /tmp/temp_gdb_command_file
        echo "info sharedlibrary" >> /tmp/temp_gdb_command_file
        echo "quit" >> /tmp/temp_gdb_command_file
        gdb < /tmp/temp_gdb_command_file > /tmp/temp_gdb.log

#create a tar file and add executable plus core
        echo collecting corefile and executable ...
        #rm -f libs_all.tar.gz
        tar -cvf $OUTPUTFILE $EXECFILE $COREFILE 2> /dev/null

#Collect the libraries loaded and update the tar
        echo collecting libraries...
        #grep -i yes /tmp/temp_gdb.log | grep -i 0x | awk '{print $NF}' > /tmp/temp_liball.log
	grep lib /tmp/temp_gdb.log | grep -E ".so|.sl" > /tmp/temp_liball.log
        for i in `cat /tmp/temp_liball.log`
        do
            tar -uvhf $OUTPUTFILE $i 2>/dev/null        #h option will follow the links as well
        done

        compress $OUTPUTFILE
        echo
        echo "Collected all the libs, executable and core."
        echo "upload $OUTPUTFILE.Z"

        # Delete temporary files
        #rm -rf /tmp/temp_gdb_command_file /tmp/temp_gdb.log /tmp/temp_liball.log libs
        exit 0
}

#on AIX we we use the inbuilt command snapcore to collect the library and core
collectLibsAIX(){
#just provide the wrapper over snapcore command
	/usr/sbin/snapcore -d ./ $COREFILE $EXECFILE

}

collectLibsDarwin(){
#Preparng the gdb command file
        echo "file $EXECFILE" > /tmp/temp_gdb_command_file
        echo "core $COREFILE" >> /tmp/temp_gdb_command_file
        echo "info sharedlibrary" >> /tmp/temp_gdb_command_file
        echo "quit" >> /tmp/temp_gdb_command_file
        gdb -x /tmp/temp_gdb_command_file > /tmp/temp_gdb.log 2>/dev/null

#create a tar file and add executable plus core
        echo collecting corefile and executable ...
        #rm -f libs_all.tar.gz
        tar -cvf $OUTPUTFILE $COREFILE 2> /dev/null

#Collect the libraries loaded and update the tar
        echo collecting libraries...
        cat /tmp/temp_gdb.log | grep -i '(objfile is) \[memory object' | awk '{gsub(/"/,"",$5);print $5}' > /tmp/temp_liball.log
        for i in `cat /tmp/temp_liball.log`
        do
            tar uvhf $OUTPUTFILE $i 2>/dev/null #h option will follow the links as well
        done

        gzip $OUTPUTFILE
        echo
        echo "Collected all the libs, executable and core."
        echo "upload $OUTPUTFILE.gz"

        # Delete temporary files
        rm -rf /tmp/temp_gdb_command_file /tmp/temp_gdb.log /tmp/temp_liball.log libs
        exit 0
}

whichOS()
{
        os=`uname`
        case $os in
                SunOS)  echo SunOS
			collectLibsSunOS $EXECFILE $COREFILE $OUTPUTFILE
                        ;;
                HP-UX)  echo HP-UX
			collectLibsHPUX $EXECFILE $COREFILE $OUTPUTFILE
                        ;;
                AIX)    echo AIX
			collectLibsAIX $EXECFILE $COREFILE $OUTPUTFILE
                        ;;
                Linux)  echo Platform Linux
			collectLibsLinux $EXECFILE $COREFILE $OUTPUTFILE
                        ;;
                Darwin)  echo Platform Mac OS X \(Darwin\) 
			 collectLibsDarwin $EXECFILE $COREFILE $OUTPUTFILE
                         ;;
        esac
}

if [ $# -ne 2 ]
then
    printusage
else
	printbanner
    EXECFILE=$1
    COREFILE=$2
    OUTPUTFILE=$COREFILE"_libs_all.tar"
    #echo $OUTPUTFILE
    checkfileexists $EXECFILE $COREFILE
    whichOS $EXECFILE $COREFILE $OUTPUTFILE
fi
